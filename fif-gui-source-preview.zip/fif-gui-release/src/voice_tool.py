"""目标音色 WAV 获取与校验工具。

功能：
1. check   —— 校验 wav 是否适合做 YourTTS 参考音频（时长/采样率/声道/音量/静音比例）
2. convert —— 用 ffmpeg 把任意音频转成规范 wav（22.05kHz 单声道 16bit）
3. record  —— 从麦克风录制一段参考音频
4. builtin —— 无参考音频时，用 YourTTS 内置音色直接生成 draft/target_voice.wav
5. probe   —— 列出 YourTTS 可用内置说话人

用法：
    python src/voice_tool.py check   draft/target_voice.wav
    python src/voice_tool.py convert input.mp3 draft/target_voice.wav
    python src/voice_tool.py record  draft/target_voice.wav --seconds 15
    python src/voice_tool.py builtin draft/target_voice.wav --speaker random
    python src/voice_tool.py probe
"""

from __future__ import annotations

import argparse
import math
import os
import shutil
import struct
import subprocess
import sys
import wave

TARGET_RATE = 22050
TARGET_CHANNELS = 1
TARGET_WIDTH = 2  # 16-bit

MIN_SECONDS = 6.0
IDEAL_SECONDS = (10.0, 40.0)


# ============================================================ WAV 基础
def read_wav_info(path: str) -> dict:
    with wave.open(path, "rb") as wf:
        frames = wf.getnframes()
        rate = wf.getframerate()
        ch = wf.getnchannels()
        width = wf.getsampwidth()
        duration = frames / float(rate) if rate else 0.0
        raw = wf.readframes(frames)
    return {
        "path": path,
        "frames": frames,
        "rate": rate,
        "channels": ch,
        "width": width,
        "duration": duration,
        "raw": raw,
        "size": os.path.getsize(path),
    }


def analyze_samples(raw: bytes, width: int) -> dict:
    """粗算峰值与 RMS、静音比例（不依赖 numpy）。"""
    if width != 2 or not raw:
        return {"peak": 0, "rms": 0, "silence_ratio": 1.0, "clipped": 0}

    total = len(raw) // 2
    peak = 0
    sq = 0
    silent = 0
    clipped = 0
    # 逐样本统计；长音频抽样即可
    step = max(1, total // 400000)
    counted = 0
    for i in range(0, total, step):
        (s,) = struct.unpack_from("<h", raw, i * 2)
        a = abs(s)
        if a > peak:
            peak = a
        sq += s * s
        if a < 200:  # 约 -44dBFS 以下算静音
            silent += 1
        if a >= 32700:
            clipped += 1
        counted += 1

    rms = math.sqrt(sq / counted) if counted else 0
    return {
        "peak": peak,
        "rms": rms,
        "peak_dbfs": 20 * math.log10(peak / 32768) if peak else -99,
        "rms_dbfs": 20 * math.log10(rms / 32768) if rms else -99,
        "silence_ratio": silent / counted if counted else 1.0,
        "clipped": clipped,
    }


# ============================================================ check
def cmd_check(args) -> int:
    path = args.path
    if not os.path.exists(path):
        print(f"[check] 文件不存在: {path}")
        return 1

    info = read_wav_info(path)
    stats = analyze_samples(info["raw"], info["width"])
    dur = info["duration"]

    print(f"[check] 文件: {path}")
    print(f"[check] 时长: {dur:.2f}s  采样率: {info['rate']}Hz  "
          f"声道: {info['channels']}  位深: {info['width'] * 8}bit  "
          f"大小: {info['size'] / 1024:.1f}KB")
    print(f"[check] 峰值: {stats['peak_dbfs']:.1f} dBFS  "
          f"RMS: {stats['rms_dbfs']:.1f} dBFS  "
          f"静音占比: {stats['silence_ratio'] * 100:.1f}%  "
          f"削波样本: {stats['clipped']}")

    problems = []
    warnings = []

    if dur < MIN_SECONDS:
        problems.append(f"时长过短（{dur:.1f}s），建议至少 {MIN_SECONDS:.0f}s")
    elif not (IDEAL_SECONDS[0] <= dur <= IDEAL_SECONDS[1]):
        warnings.append(f"时长 {dur:.1f}s 不在推荐区间 "
                        f"{IDEAL_SECONDS[0]:.0f}-{IDEAL_SECONDS[1]:.0f}s")

    if info["rate"] < 16000:
        problems.append(f"采样率过低（{info['rate']}Hz），建议 >= 16000")
    elif info["rate"] != TARGET_RATE:
        warnings.append(f"采样率 {info['rate']}Hz，规范值 {TARGET_RATE}Hz（可 convert 转换）")

    if info["channels"] != TARGET_CHANNELS:
        warnings.append(f"声道数 {info['channels']}，建议单声道（可 convert 转换）")

    if info["width"] != TARGET_WIDTH:
        warnings.append(f"位深 {info['width'] * 8}bit，建议 16bit（可 convert 转换）")

    if stats["silence_ratio"] > 0.6:
        problems.append(f"静音占比过高（{stats['silence_ratio'] * 100:.0f}%），录音可能空白")
    elif stats["silence_ratio"] > 0.4:
        warnings.append(f"静音占比偏高（{stats['silence_ratio'] * 100:.0f}%）")

    if stats["peak_dbfs"] < -30:
        problems.append(f"音量过低（峰值 {stats['peak_dbfs']:.1f} dBFS），请调高录音增益")
    elif stats["peak_dbfs"] < -12:
        warnings.append(f"音量偏低（峰值 {stats['peak_dbfs']:.1f} dBFS）")

    if stats["clipped"] > 0:
        warnings.append(f"存在削波（{stats['clipped']} 样本），可能爆音")

    for w in warnings:
        print(f"[warn ] {w}")
    for p in problems:
        print(f"[error] {p}")

    if problems:
        print("[check] 结论: 不适合作为参考音频，请按上面提示修复。")
        return 2
    print("[check] 结论: 可用于 YourTTS 参考音频。" +
          ("（建议按 warn 优化）" if warnings else ""))
    return 0


# ============================================================ convert
def cmd_convert(args) -> int:
    src, dst = args.src, args.dst
    if not os.path.exists(src):
        print(f"[convert] 输入不存在: {src}")
        return 1

    os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)
    ffmpeg = shutil.which("ffmpeg")

    if ffmpeg:
        cmd = [
            ffmpeg, "-y", "-i", src,
            "-ac", str(TARGET_CHANNELS),
            "-ar", str(TARGET_RATE),
            "-acodec", "pcm_s16le",
        ]
        # 若指定裁剪
        if args.trim is not None:
            cmd += ["-t", str(args.trim)]
        cmd.append(dst)
        print(f"[convert] 调用 ffmpeg: {' '.join(cmd)}")
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            print("[convert] ffmpeg 失败:")
            print(r.stderr[-1500:])
            return 1
        print(f"[convert] 完成 -> {dst}")
    else:
        # 无 ffmpeg：只支持同格式 wav 的重采样（简单抽取）
        print("[convert] 未找到 ffmpeg，尝试纯 Python 处理（仅支持 wav 输入）")
        if not src.lower().endswith(".wav"):
            print("[convert] 非 wav 输入需要 ffmpeg，请安装后重试。")
            return 1
        info = read_wav_info(src)
        raw = info["raw"]
        width = info["width"]
        ch = info["channels"]

        if width != 2:
            print("[convert] 纯 Python 模式仅支持 16bit wav。")
            return 1

        # 立体声 -> 单声道
        if ch == 2:
            out = bytearray()
            for i in range(0, len(raw) - 3, 4):
                l = struct.unpack_from("<h", raw, i)[0]
                rr = struct.unpack_from("<h", raw, i + 2)[0]
                avg = int((l + rr) / 2)
                out += struct.pack("<h", avg)
            raw = bytes(out)
        elif ch != 1:
            print(f"[convert] 不支持 {ch} 声道。")
            return 1

        # 线性重采样
        if info["rate"] != TARGET_RATE:
            total = len(raw) // 2
            ratio = TARGET_RATE / float(info["rate"])
            new_total = int(total * ratio)
            out = bytearray()
            for i in range(new_total):
                pos = int(i / ratio)
                pos = min(pos, total - 1)
                out += raw[pos * 2:pos * 2 + 2]
            raw = bytes(out)

        if args.trim is not None:
            keep = int(TARGET_RATE * args.trim) * 2
            raw = raw[:keep]

        with wave.open(dst, "wb") as wf:
            wf.setnchannels(TARGET_CHANNELS)
            wf.setsampwidth(TARGET_WIDTH)
            wf.setframerate(TARGET_RATE)
            wf.writeframes(raw)
        print(f"[convert] 完成（纯 Python）-> {dst}")

    # 转换后校验
    class _A:
        pass
    a = _A()
    a.path = dst
    return cmd_check(a)


# ============================================================ record
def cmd_record(args) -> int:
    try:
        import pyaudio
    except Exception:
        print("[record] 需要 pyaudio，请先 pip install pyaudio")
        return 1

    dst = args.dst
    os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)

    p = pyaudio.PyAudio()
    chunk = 1024
    fmt = p.get_format_from_width(TARGET_WIDTH)
    try:
        dev_index = None
        if args.device:
            target = args.device.lower()
            for i in range(p.get_device_count()):
                info = p.get_device_info_by_index(i)
                if int(info.get("maxInputChannels", 0)) > 0 and \
                        target in str(info.get("name", "")).lower():
                    dev_index = i
                    print(f"[record] 使用输入设备 [{i}] {info.get('name')}")
                    break
            if dev_index is None:
                print(f"[record] 未找到匹配 '{args.device}' 的输入设备，使用默认。")
        if dev_index is None:
            default = p.get_default_input_device_info()
            print(f"[record] 使用默认输入设备: {default.get('name')}")

        stream = p.open(format=fmt, channels=TARGET_CHANNELS,
                        rate=TARGET_RATE, input=True,
                        input_device_index=dev_index, frames_per_buffer=chunk)

        frames = []
        total_chunks = int(TARGET_RATE / chunk * args.seconds)
        print(f"[record] 开始录音 {args.seconds}s，请朗读一段英文（约 3-6 句）...")
        for i in range(total_chunks):
            frames.append(stream.read(chunk, exception_on_overflow=False))
            if i % max(1, total_chunks // 10) == 0:
                pct = int(i / total_chunks * 100)
                print(f"[record] 进度 {pct}%")
        stream.stop_stream()
        stream.close()

        with wave.open(dst, "wb") as wf:
            wf.setnchannels(TARGET_CHANNELS)
            wf.setsampwidth(TARGET_WIDTH)
            wf.setframerate(TARGET_RATE)
            wf.writeframes(b"".join(frames))
        print(f"[record] 已保存 -> {dst}")
    finally:
        p.terminate()

    class _A:
        pass
    a = _A()
    a.path = dst
    return cmd_check(a)


# ============================================================ builtin
def cmd_builtin(args) -> int:
    try:
        from TTS.api import TTS
    except Exception:
        print("[builtin] 需要 coqui-tts，请先安装依赖。")
        return 1

    dst = args.dst
    os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)

    print("[builtin] 正在加载 YourTTS...")
    try:
        tts = TTS(args.model, gpu=False, progress_bar=True)
    except TypeError:
        tts = TTS(args.model, progress_bar=True)

    speakers = getattr(tts, "speakers", None) or []
    if not speakers:
        print("[builtin] 该模型无内置说话人列表，无法生成。改用 record 录制。")
        return 1

    speaker = speakers[0] if args.speaker == "random" else args.speaker
    if speaker not in speakers:
        print(f"[builtin] 说话人 '{speaker}' 不存在，可选: {speakers}")
        return 1

    text = args.text or (
        "Hello, this is a reference voice sample for speech synthesis. "
        "The quick brown fox jumps over the lazy dog. "
        "I enjoy learning English and practicing my speaking skills every day. "
        "Reading aloud helps me improve my pronunciation and fluency. "
        "Please listen carefully to the rhythm and intonation of these sentences. "
        "Thank you for helping me prepare this voice sample."
    )
    print(f"[builtin] 使用说话人: {speaker}")
    print(f"[builtin] 合成参考音频 -> {dst}")
    tts.tts_to_file(text=text, speaker=speaker, language="en", file_path=dst)
    print(f"[builtin] 完成 -> {dst}")

    class _A:
        pass
    a = _A()
    a.path = dst
    return cmd_check(a)


# ============================================================ probe
def cmd_probe(args) -> int:
    try:
        from TTS.api import TTS
    except Exception:
        print("[probe] 需要 coqui-tts。")
        return 1
    try:
        tts = TTS(args.model, gpu=False, progress_bar=False)
    except TypeError:
        tts = TTS(args.model, progress_bar=False)

    speakers = getattr(tts, "speakers", None) or []
    languages = getattr(tts, "languages", None) or []
    print(f"[probe] 模型: {args.model}")
    print(f"[probe] 语言: {languages}")
    print(f"[probe] 内置说话人（{len(speakers)}）:")
    for s in speakers:
        print(f"  - {s}")
    return 0


# ============================================================ main
def main() -> int:
    parser = argparse.ArgumentParser(description="FiF 音色样本工具")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_check = sub.add_parser("check", help="校验参考音频")
    p_check.add_argument("path")
    p_check.set_defaults(func=cmd_check)

    p_conv = sub.add_parser("convert", help="转换为规范 wav")
    p_conv.add_argument("src")
    p_conv.add_argument("dst")
    p_conv.add_argument("--trim", type=float, default=None, help="裁剪到指定秒数")
    p_conv.set_defaults(func=cmd_convert)

    p_rec = sub.add_parser("record", help="录制参考音频")
    p_rec.add_argument("dst")
    p_rec.add_argument("--seconds", type=float, default=15.0)
    p_rec.add_argument("--device", default=None, help="输入设备名关键字")
    p_rec.set_defaults(func=cmd_record)

    p_bi = sub.add_parser("builtin", help="用内置音色生成参考音频")
    p_builtin_model = "tts_models/multilingual/multi-dataset/your_tts"
    p_bi.add_argument("dst")
    p_bi.add_argument("--speaker", default="random")
    p_bi.add_argument("--text", default=None)
    p_bi.add_argument("--model", default=p_builtin_model)
    p_bi.set_defaults(func=cmd_builtin)

    p_pr = sub.add_parser("probe", help="列出内置说话人")
    p_pr.add_argument("--model", default="tts_models/multilingual/multi-dataset/your_tts")
    p_pr.set_defaults(func=cmd_probe)

    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
