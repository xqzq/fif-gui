"""FiF 口语自动化工具 —— 主力 GUI 入口（补丁版）。

改动摘要：
- 逐等级异常隔离：单个等级失败不影响整体任务。
- 挑战次数预检（getStudentTaskChallengeConfig）。
- 跳过规则 / 等级类型规则沿用并强化。
- 支持 dry-run（只取答案不播放）、headless、虚拟麦克风设备名配置。
- 日志同时输出到 GUI 与 logs/ 文件。
"""

from __future__ import annotations

import json
import logging
import os
import platform
import re
import sys
import threading
import tkinter as tk
import traceback
from tkinter import filedialog, messagebox, ttk

# 允许以 src/main.py 直接运行
SRC_DIR = os.path.dirname(os.path.abspath(__file__))
if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)

from checkpoint import Checkpoint  # noqa: E402
from connector.FiFWebClient import FiFWebClient  # noqa: E402
from speaker.Speaker import Speaker  # noqa: E402

os.makedirs("tmp", exist_ok=True)
os.makedirs("draft", exist_ok=True)
os.makedirs("logs", exist_ok=True)
os.makedirs("state", exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[logging.FileHandler("logs/fif_gui.log", encoding="utf-8")],
)
logger = logging.getLogger("fif_gui")


DEFAULT_CONFIG = {
    "username": "",
    "password": "",
    "skip_score": 80,
    "target_voice_path": "draft/target_voice.wav",
    "tts_model": "tts_models/multilingual/multi-dataset/your_tts",
    "tts_mode": "cpu",
    "vmic_name": "VirtualPipeMic",
    "output_device": "CABLE Input",
    "bank_type": "1",
    "headless": False,
    "dry_run": True,
    "resume": True,
    "max_retries": 2,
    "skip_rules": [],
    "level_type_rules": [],
}


class FiFApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("FiF口语自动化工具（补丁版）")
        self.root.geometry("760x640")
        self.root.resizable(False, False)

        self.username = tk.StringVar()
        self.password = tk.StringVar()
        self.skip_score = tk.IntVar(value=80)
        self.target_voice_path = tk.StringVar(value="draft/target_voice.wav")
        self.tts_model = tk.StringVar(value=DEFAULT_CONFIG["tts_model"])
        self.tts_mode = tk.StringVar(value="cpu")
        self.vmic_name = tk.StringVar(value="VirtualPipeMic")
        self.output_device = tk.StringVar(value="CABLE Input")
        self.bank_type = tk.StringVar(value="1")
        self.headless = tk.BooleanVar(value=False)
        self.dry_run = tk.BooleanVar(value=True)
        self.resume = tk.BooleanVar(value=True)
        self.max_retries = tk.IntVar(value=2)

        self.is_running = False
        self.skip_rules: list = []
        self.level_type_rules: list = []
        self.ckpt = Checkpoint()

        self.create_widgets()
        self.load_config()

    # ================================================== UI
    def create_widgets(self) -> None:
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=10)

        self._build_login_tab()
        self._build_skip_tab()
        self._build_level_type_tab()

        # 控制按钮
        control = ttk.Frame(self.root)
        control.pack(fill="x", padx=10, pady=5)

        self.start_btn = ttk.Button(control, text="开始运行", command=self.toggle_run)
        self.start_btn.pack(side="left", padx=5)
        ttk.Button(control, text="保存配置", command=self.save_config).pack(side="left", padx=5)
        ttk.Button(control, text="环境自检", command=self.self_check).pack(side="left", padx=5)
        ttk.Button(control, text="进度统计", command=self.show_progress).pack(side="left", padx=5)
        ttk.Button(control, text="清除进度", command=self.clear_progress).pack(side="left", padx=5)

        # 日志
        log_frame = ttk.LabelFrame(self.root, text="运行日志", padding=10)
        log_frame.pack(fill="both", expand=True, padx=10, pady=10)
        self.log_text = tk.Text(log_frame, height=20, state="disabled")
        scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scroll.set)
        self.log_text.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

    def _build_login_tab(self) -> None:
        f = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(f, text="登录配置")
        f.columnconfigure(1, weight=1)

        rows = [
            ("用户名:", self.username, None, None),
            ("密码:", self.password, None, "*"),
            ("目标音色文件:", self.target_voice_path, "browse", None),
            ("TTS 模型:", self.tts_model, None, None),
        ]
        for i, (label, var, action, show) in enumerate(rows):
            ttk.Label(f, text=label).grid(row=i, column=0, sticky="w", pady=5)
            entry = ttk.Entry(f, textvariable=var, width=38, show=show)
            entry.grid(row=i, column=1, pady=5, padx=5, sticky="ew")
            if action == "browse":
                ttk.Button(f, text="浏览", command=self.browse_voice_file).grid(row=i, column=2)

        # 跳过分数
        r = len(rows)
        ttk.Label(f, text="跳过分数:").grid(row=r, column=0, sticky="w", pady=5)
        score_frame = ttk.Frame(f)
        score_frame.grid(row=r, column=1, sticky="ew", pady=5, padx=5)
        ttk.Scale(
            score_frame, from_=0, to=100, variable=self.skip_score,
            orient="horizontal", command=self.on_scale_change,
        ).pack(side="left", fill="x", expand=True)
        score_entry = ttk.Entry(score_frame, textvariable=self.skip_score, width=5)
        score_entry.pack(side="right", padx=(5, 0))
        score_entry.bind("<Return>", self.on_entry_change)
        score_entry.bind("<FocusOut>", self.on_entry_change)

        # 运行参数
        r += 1
        ttk.Label(f, text="TTS 设备:").grid(row=r, column=0, sticky="w", pady=5)
        ttk.Combobox(
            f, textvariable=self.tts_mode, state="readonly",
            values=("cpu", "cuda"), width=12,
        ).grid(row=r, column=1, sticky="w", pady=5, padx=5)

        r += 1
        ttk.Label(f, text="虚拟麦克风名:").grid(row=r, column=0, sticky="w", pady=5)
        ttk.Entry(f, textvariable=self.vmic_name, width=38).grid(
            row=r, column=1, pady=5, padx=5, sticky="ew"
        )

        r += 1
        ttk.Label(f, text="输出设备(VB-Cable):").grid(row=r, column=0, sticky="w", pady=5)
        ttk.Entry(f, textvariable=self.output_device, width=38).grid(
            row=r, column=1, pady=5, padx=5, sticky="ew"
        )

        r += 1
        ttk.Label(f, text="bankType:").grid(row=r, column=0, sticky="w", pady=5)
        ttk.Entry(f, textvariable=self.bank_type, width=10).grid(
            row=r, column=1, sticky="w", pady=5, padx=5
        )

        r += 1
        opts = ttk.Frame(f)
        opts.grid(row=r, column=0, columnspan=3, sticky="w", pady=5)
        ttk.Checkbutton(opts, text="无头模式", variable=self.headless).pack(side="left", padx=5)
        ttk.Checkbutton(opts, text="Dry-run（只取答案不播放）", variable=self.dry_run).pack(
            side="left", padx=5
        )
        ttk.Checkbutton(opts, text="断点续跑", variable=self.resume).pack(side="left", padx=5)

        r += 1
        ttk.Label(f, text="单关卡最大重试:").grid(row=r, column=0, sticky="w", pady=5)
        ttk.Spinbox(f, from_=0, to=10, textvariable=self.max_retries, width=5).grid(
            row=r, column=1, sticky="w", pady=5, padx=5
        )

    def _build_skip_tab(self) -> None:
        f = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(f, text="跳过设置")

        ttk.Label(f, text="单元匹配文本（例如 Unit 1）:").grid(row=0, column=0, sticky="w", pady=5)
        self.skip_unit_entry = ttk.Entry(f, width=25)
        self.skip_unit_entry.grid(row=0, column=1, pady=5, padx=5)

        ttk.Label(f, text="等级类型:").grid(row=1, column=0, sticky="w", pady=5)
        self.chapter_type = tk.StringVar(value="Any")
        combo = ttk.Combobox(
            f, textvariable=self.chapter_type, state="readonly", width=22,
            values=("Any", "Role-play", "Expressions", "Group discussion"),
        )
        combo.grid(row=1, column=1, pady=5, padx=5)

        ttk.Label(f, text="等级编号（可选）:").grid(row=2, column=0, sticky="w", pady=5)
        self.chapter_num_entry = ttk.Entry(f, width=10)
        self.chapter_num_entry.grid(row=2, column=1, pady=5, padx=5, sticky="w")

        ttk.Button(f, text="添加跳过规则", command=self.add_skip_rule).grid(row=3, column=0, pady=10)
        ttk.Button(f, text="删除选中规则", command=self.remove_selected_rule).grid(
            row=3, column=1, pady=10, sticky="w"
        )
        self.skip_listbox = tk.Listbox(f, height=8)
        self.skip_listbox.grid(row=4, column=0, columnspan=2, sticky="nsew", pady=5)
        f.columnconfigure(1, weight=1)

    def _build_level_type_tab(self) -> None:
        f = ttk.Frame(self.notebook, padding=10)
        self.notebook.add(f, text="等级类型规则")

        ttk.Label(f, text="单元匹配文本:").grid(row=0, column=0, sticky="w", pady=5)
        self.lt_unit_entry = ttk.Entry(f, width=25)
        self.lt_unit_entry.grid(row=0, column=1, pady=5, padx=5)

        ttk.Label(f, text="等级匹配文本:").grid(row=1, column=0, sticky="w", pady=5)
        self.lt_level_entry = ttk.Entry(f, width=25)
        self.lt_level_entry.grid(row=1, column=1, pady=5, padx=5)

        ttk.Label(f, text="类型（Role-play=对话，Read=跟读）:").grid(row=2, column=0, sticky="w", pady=5)
        self.level_type_var = tk.StringVar(value="Role-play")
        ttk.Combobox(
            f, textvariable=self.level_type_var, state="readonly", width=22,
            values=("Role-play", "Read"),
        ).grid(row=2, column=1, pady=5, padx=5)

        ttk.Button(f, text="添加等级类型规则", command=self.add_level_type_rule).grid(
            row=3, column=0, pady=10
        )
        ttk.Button(f, text="删除选中规则", command=self.remove_selected_level_type_rule).grid(
            row=3, column=1, pady=10, sticky="w"
        )
        self.lt_listbox = tk.Listbox(f, height=8)
        self.lt_listbox.grid(row=4, column=0, columnspan=2, sticky="nsew", pady=5)
        f.columnconfigure(1, weight=1)

    # ================================================== 配置读写
    def load_config(self) -> None:
        if not os.path.exists("config.json"):
            return
        try:
            with open("config.json", "r", encoding="utf-8") as f:
                cfg = json.load(f)
        except Exception as e:
            self.log_message(f"加载配置失败: {e}")
            return

        self.username.set(cfg.get("username", ""))
        self.password.set(cfg.get("password", ""))
        self.skip_score.set(int(cfg.get("skip_score", 80)))
        self.target_voice_path.set(cfg.get("target_voice_path", "draft/target_voice.wav"))
        self.tts_model.set(cfg.get("tts_model", DEFAULT_CONFIG["tts_model"]))
        self.tts_mode.set(cfg.get("tts_mode", "cpu"))
        self.vmic_name.set(cfg.get("vmic_name", "VirtualPipeMic"))
        self.output_device.set(cfg.get("output_device", "CABLE Input"))
        self.bank_type.set(str(cfg.get("bank_type", "1")))
        self.headless.set(bool(cfg.get("headless", False)))
        self.dry_run.set(bool(cfg.get("dry_run", True)))
        self.resume.set(bool(cfg.get("resume", True)))
        self.max_retries.set(int(cfg.get("max_retries", 2)))
        self.skip_rules = cfg.get("skip_rules", []) or []
        self.level_type_rules = cfg.get("level_type_rules", []) or []
        self.refresh_skip_listbox()
        self.refresh_level_type_listbox()

    def save_config(self) -> None:
        cfg = {
            "username": self.username.get(),
            "password": self.password.get(),
            "skip_score": self.skip_score.get(),
            "target_voice_path": self.target_voice_path.get(),
            "tts_model": self.tts_model.get(),
            "tts_mode": self.tts_mode.get(),
            "vmic_name": self.vmic_name.get(),
            "output_device": self.output_device.get(),
            "bank_type": self.bank_type.get(),
            "headless": self.headless.get(),
            "dry_run": self.dry_run.get(),
            "resume": self.resume.get(),
            "max_retries": self.max_retries.get(),
            "skip_rules": self.skip_rules,
            "level_type_rules": self.level_type_rules,
        }
        try:
            with open("config.json", "w", encoding="utf-8") as f:
                json.dump(cfg, f, ensure_ascii=False, indent=2)
            self.log_message("配置已保存。")
        except Exception as e:
            self.log_message(f"保存配置失败: {e}")

    # ================================================== 规则
    def on_scale_change(self, value) -> None:
        try:
            self.skip_score.set(int(float(value)))
        except ValueError:
            pass

    def on_entry_change(self, _event) -> None:
        try:
            v = int(self.score_entry_get())
            if 0 <= v <= 100:
                self.skip_score.set(v)
            else:
                messagebox.showerror("错误", "分数必须在 0-100 之间")
                self.skip_score.set(80)
        except ValueError:
            messagebox.showerror("错误", "请输入有效数字")
            self.skip_score.set(80)

    def score_entry_get(self) -> str:
        # 找到分数输入框的值
        return str(self.skip_score.get())

    def browse_voice_file(self) -> None:
        filename = filedialog.askopenfilename(
            title="选择目标音色文件",
            filetypes=[("WAV 文件", "*.wav"), ("所有文件", "*.*")],
        )
        if filename:
            self.target_voice_path.set(filename)

    def add_skip_rule(self) -> None:
        unit = self.skip_unit_entry.get().strip()
        if not unit:
            messagebox.showerror("错误", "请填写单元匹配文本，例如 Unit 1")
            return
        self.skip_rules.append({
            "unit_pattern": unit,
            "chapter_type": self.chapter_type.get().strip(),
            "chapter_num": self.chapter_num_entry.get().strip(),
        })
        self.refresh_skip_listbox()

    def remove_selected_rule(self) -> None:
        sel = self.skip_listbox.curselection()
        if sel:
            self.skip_rules.pop(sel[0])
            self.refresh_skip_listbox()

    def refresh_skip_listbox(self) -> None:
        self.skip_listbox.delete(0, "end")
        for r in self.skip_rules:
            cnum = r.get("chapter_num", "")
            text = f"{r.get('unit_pattern','')} · {r.get('chapter_type','Any')}"
            if cnum:
                text += f" {cnum}"
            self.skip_listbox.insert("end", text)

    def should_skip(self, unit_name: str, level_name: str) -> bool:
        if not unit_name:
            return False
        for r in self.skip_rules:
            upat = r.get("unit_pattern", "").lower()
            ctype = r.get("chapter_type", "Any")
            cnum = str(r.get("chapter_num", "")).strip()

            if upat and upat not in unit_name.lower():
                continue
            if ctype == "Any" or not ctype:
                return True
            if not level_name:
                continue
            lname = level_name.lower()
            if ctype.lower() in lname:
                if not cnum:
                    return True
                nums = re.findall(r"(\d+)", level_name)
                if nums and cnum in nums:
                    return True
                if cnum in level_name:
                    return True
        return False

    def add_level_type_rule(self) -> None:
        unit = self.lt_unit_entry.get().strip()
        level = self.lt_level_entry.get().strip()
        if not unit and not level:
            messagebox.showerror("错误", "请至少填写单元或等级匹配文本")
            return
        self.level_type_rules.append({
            "unit_pattern": unit,
            "level_pattern": level,
            "level_type": self.level_type_var.get().strip(),
        })
        self.refresh_level_type_listbox()

    def remove_selected_level_type_rule(self) -> None:
        sel = self.lt_listbox.curselection()
        if sel:
            self.level_type_rules.pop(sel[0])
            self.refresh_level_type_listbox()

    def refresh_level_type_listbox(self) -> None:
        self.lt_listbox.delete(0, "end")
        for r in self.level_type_rules:
            up, lp, lt = r.get("unit_pattern", ""), r.get("level_pattern", ""), r.get("level_type", "")
            self.lt_listbox.insert("end", f"{up} · {lp} · {lt}" if lp else f"{up} · {lt}")

    def _apply_level_type_rules(self, unit_name: str, level_name: str) -> str:
        if not level_name:
            return level_name
        uname, lname = (unit_name or "").lower(), level_name.lower()
        for r in self.level_type_rules:
            upat = r.get("unit_pattern", "").lower()
            lpat = r.get("level_pattern", "").lower()
            if upat and upat not in uname:
                continue
            if lpat and lpat not in lname:
                continue
            if r.get("level_type") == "Role-play":
                return level_name if "role" in lname else level_name + " role"
            return level_name
        return level_name

    # ================================================== 日志 / 自检
    def log_message(self, message: str) -> None:
        self.log_text.config(state="normal")
        self.log_text.insert("end", message + "\n")
        self.log_text.see("end")
        self.log_text.config(state="disabled")
        print(message)

    def show_progress(self) -> None:
        s = self.ckpt.stats()
        self.log_message(
            "[progress] 总计 {}，已完成 {}，失败 {}，待处理 {}".format(
                s["total"], s["done"], s["failed"], s["pending"]
            )
        )
        for line in self.ckpt.summary_lines(limit=30):
            self.log_message(line)

    def clear_progress(self) -> None:
        if not messagebox.askyesno("确认", "清除全部断点进度记录？"):
            return
        removed = self.ckpt.reset()
        self.log_message(f"[progress] 已清除 {removed} 条进度记录。")

    def self_check(self) -> None:
        lines = [f"[check] 运行平台: {platform.system()} {platform.release()}",
                 f"[check] Python: {sys.version.split()[0]}"]
        lines.append(f"[check] tmp/ 存在: {os.path.isdir('tmp')}")
        lines.append(f"[check] draft/ 存在: {os.path.isdir('draft')}")

        voice = self.target_voice_path.get()
        lines.append(f"[check] 音色文件存在: {os.path.exists(voice)} ({voice})")

        try:
            import playwright  # noqa: F401
            lines.append("[check] playwright: 已安装")
        except Exception:
            lines.append("[check] playwright: 缺失")

        try:
            import pyaudio
            p = pyaudio.PyAudio()
            names = []
            for i in range(p.get_device_count()):
                info = p.get_device_info_by_index(i)
                if int(info.get("maxOutputChannels", 0)) > 0:
                    names.append(f"[{i}] {info.get('name')}")
            p.terminate()
            lines.append("[check] pyaudio: 已安装")
            lines.append("[check] 输出设备: " + " | ".join(names) if names else "[check] 未发现输出设备")
        except Exception as e:
            lines.append(f"[check] pyaudio: 问题（{e}）")

        try:
            import TTS  # noqa: F401
            lines.append("[check] TTS: 已安装")
        except Exception:
            lines.append("[check] TTS: 缺失")

        for line in lines:
            self.log_message(line)

    # ================================================== 运行
    def toggle_run(self) -> None:
        if self.is_running:
            self.is_running = False
            self.start_btn.config(text="开始运行")
            self.log_message("已请求停止，当前句完成后退出。")
            return

        if not self.username.get() or not self.password.get():
            messagebox.showerror("错误", "请输入用户名和密码")
            return
        if not os.path.exists(self.target_voice_path.get()):
            messagebox.showerror("错误", "目标音色文件不存在")
            return

        self.is_running = True
        self.start_btn.config(text="停止运行")
        self.save_config()

        threading.Thread(target=self.run_main, daemon=True).start()

    def run_main(self) -> None:
        fif = None
        try:
            self.log_message(f"[main] 开始运行，平台: {platform.system()}")
            if self.resume.get():
                s = self.ckpt.stats()
                self.log_message(
                    "[main] 断点续跑已启用：历史记录 {} 条（已完成 {}，失败 {}）".format(
                        s["total"], s["done"], s["failed"]
                    )
                )
            self.log_message("[main] 正在初始化浏览器...")
            fif = FiFWebClient(headless=self.headless.get())

            self.log_message("[main] 正在初始化语音合成器...")
            speaker = Speaker(
                self.tts_model.get(),
                self.tts_mode.get(),
                self.vmic_name.get(),
                self.target_voice_path.get(),
                self.output_device.get(),
            )
            self.log_message("[main] 启动完成。")

            # 登录
            info = fif.login(self.username.get(), self.password.get())
            data = info.get("data", {})
            self.log_message(
                "[main] {} 登录成功，用户ID: {}".format(
                    data.get("realName", "?"), data.get("userId", "?")
                )
            )
            user_id = fif.get_user_id()

            # 任务列表
            task_list = fif.get_task_list(fif.get_page()).get("data", {}).get("ttiList", [])
            if not task_list:
                self.log_message("[main] 教师任务接口 status=1 的第1页为空；这不代表账号下所有练习都为空。")
                # Read-only diagnostics; never run tasks from another filter automatically.
                for filter_status in (0, 2):
                    try:
                        probe = fif.get_task_list(fif.get_page(), status=filter_status)
                        count = len(probe['data']['ttiList'])
                        self.log_message(f"[诊断] 同一教师任务接口 status={filter_status}：第1页 {count} 条（仅查看数量）。")
                    except Exception as probe_error:
                        self.log_message(f"[诊断] status={filter_status}：{probe_error}")
                if not self.headless.get():
                    self.log_message("[main] 已暂停执行。浏览器保留供检查：请查看任务页各标签；点击工具的“停止运行”或关闭浏览器后结束。")
                    try:
                        fif.get_page().goto(fif.urls['ai_task'], wait_until='domcontentloaded', timeout=30000)
                    except Exception:
                        self.log_message("[main] 自动打开任务页未完成，请在浏览器手动进入任务页。")
                    while self.is_running and fif.get_browser().is_connected():
                        pages = [p for p in fif.get_context().pages if not p.is_closed()]
                        if not pages:
                            break
                        try:
                            pages[0].wait_for_timeout(500)
                        except Exception:
                            break
                return

            for i, task in enumerate(task_list):
                if not self.is_running:
                    break
                self._run_task(fif, speaker, task, i, user_id)

            self.log_message("[main] 所有任务处理完成。")
        except Exception as e:
            self.log_message(f"[main] 发生错误: {e}")
            logger.exception("主流程异常")
        finally:
            if fif is not None:
                fif.close()
            self.is_running = False
            self.root.after(0, lambda: self.start_btn.config(text="开始运行"))

    def _run_task(self, fif, speaker, task, index, user_id) -> None:
        ttd_list = fif.get_ttd_list(fif.get_page(), task["id"]).get("data", {}).get("ttdList", [])
        self.log_message(
            "[main] 第 {} 个任务：{}（ID {}）".format(index + 1, task.get("taskName"), task.get("id"))
        )

        for j, ttd in enumerate(ttd_list):
            if not self.is_running:
                return
            unit_name = ttd.get("unitName", "")
            self.log_message(
                "[main] 第 {} 个单元：{}（ID {}）".format(j + 1, unit_name, ttd.get("id"))
            )

            try:
                unit_info = fif.get_unit_info(
                    fif.get_page(), ttd["unitid"], task["taskId"], self.bank_type.get()
                ).get("data", {})
            except Exception as e:
                self.log_message(f"[main] 获取单元信息失败，跳过：{e}")
                continue

            for k, level in enumerate(unit_info.get("levelList", [])):
                if not self.is_running:
                    return
                self._run_level(fif, speaker, level, k, unit_name, task, unit_info, user_id)

    def _run_level(self, fif, speaker, level, k, unit_name, task, unit_info, user_id) -> None:
        level_name = level.get("levelName", "")
        level_id = level.get("levelId")
        task_id = task["id"]
        unit_id = unit_info["id"]

        try:
            # 断点续跑：已完成 / 超重试上限 直接跳过
            if self.resume.get():
                ok, reason = self.ckpt.should_process(
                    task_id, unit_id, level_id,
                    skip_done=True, max_retries=self.max_retries.get(),
                )
                if not ok:
                    self.log_message(f"[main] 跳过 {level_name}：{reason}")
                    return

            if self.should_skip(unit_name, level_name):
                self.log_message(f"[main] 跳过规则命中：{unit_name} / {level_name}")
                return

            if level.get("levelScore", 0) >= self.skip_score.get():
                self.log_message(f"[main] 已达标跳过：{level_name}（{level.get('levelScore')}）")
                return

            # 挑战次数预检
            try:
                cfg = fif.get_challenge_config(
                    fif.get_page(), task_id, level_id, user_id
                ).get("data", {}) or {}
                used = int(cfg.get("answerCount", 0) or 0)
                limit = int(cfg.get("challengeTimes", 0) or 0)
                if limit and (used + 1) > limit:
                    self.log_message(f"[main] 挑战次数已用尽，跳过：{level_name}")
                    return
            except Exception as e:
                logger.warning("挑战配置预检失败: %s", e)

            self.log_message(
                "[main] 第 {} 个等级：{}（ID {}）".format(k + 1, level_name, level_id)
            )

            if self.dry_run.get():
                answers = fif.get_level_answer(fif.get_page(), level_id, level_name)
                self.log_message(f"[main][dry-run] {level_name} 答案 {len(answers)} 条：{answers[:3]}")
                return

            fif.start_level_test(
                fif.get_page(),
                speaker,
                unit_id=unit_id,
                task_id=task_id,
                level_id=level_id,
                level_name=self._apply_level_type_rules(unit_name, level_name),
                bank_type=self.bank_type.get(),
            )
            self.ckpt.mark_done(task_id, unit_id, level_id, level_name=level_name)
            self.log_message(f"[main] 第 {k + 1} 个等级完成。")
        except Exception as e:
            # 单等级异常隔离 + 记录失败次数
            fails = self.ckpt.mark_failed(
                task_id, unit_id, level_id, error=str(e), level_name=level_name
            )
            self.log_message(
                f"[main] 等级 {level_name} 失败（第 {fails} 次），继续后续：{e}"
            )
            logger.error("等级失败 %s\n%s", level_name, traceback.format_exc())


def main() -> None:
    os.makedirs("tmp", exist_ok=True)
    os.makedirs("draft", exist_ok=True)
    os.makedirs("logs", exist_ok=True)
    os.makedirs("state", exist_ok=True)
    root = tk.Tk()
    FiFApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
