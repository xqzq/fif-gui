"""Coqui TTS 封装。

相对上游 fif_gui 的改动：
- 兼容 coqui-tts 新旧 API（TTS(...) 与 TTS(..., gpu=...)）。
- 合成前做数字 / 货币朗读规范化。
- 单个短词前缀 "Oh, " 规避短句合成 bug。
- 增加重复合成缓存，减少同一句重复推理。
"""

from __future__ import annotations

import os
import re
import tempfile
from pathlib import Path
from typing import Optional

try:
    from TTS.api import TTS
except Exception:  # pragma: no cover
    TTS = None

try:
    from num2words import num2words
except Exception:  # pragma: no cover
    num2words = None


DEFAULT_MODEL = "tts_models/multilingual/multi-dataset/your_tts"
MODEL_SUBDIR = "tts_models--multilingual--multi-dataset--your_tts"


def _find_tts_home() -> Optional[str]:
    """定位项目内的 TTS_HOME（模型缓存目录）。

    bootstrap.ps1 把模型放在 <项目父目录>/_runtime/tts_home/tts/ 下，
    而 coqui-tts 默认找 %LOCALAPPDATA%\\tts。这里按优先级探测，
    命中则设置 TTS_HOME 环境变量，避免重复下载 405MB。
    """
    if os.environ.get("TTS_HOME"):
        return os.environ["TTS_HOME"]

    here = Path(__file__).resolve()
    candidates = []
    for base in (Path.cwd(), here.parent.parent.parent):  # 运行目录 / 项目根
        for root in (base, base.parent):
            candidates.append(root / "_runtime" / "tts_home")

    for c in candidates:
        if (c / "tts" / MODEL_SUBDIR / "model_file.pth").exists():
            os.environ["TTS_HOME"] = str(c)
            return str(c)
    return None


class TTSSolver:
    def __init__(self, model: str, mode: str, target_voice_path: str):
        self.model = model or DEFAULT_MODEL
        self.target_voice_path = target_voice_path
        self._mode = mode
        self._tts = None
        self._cache: dict = {}

    # ------------------------------------------------------------ 初始化
    def _ensure_tts(self) -> None:
        if self._tts is not None:
            return
        if TTS is None:
            raise RuntimeError("未安装 TTS 包，请先执行 pip install -r requirements.txt")

        found = _find_tts_home()
        if found:
            print(f"[TTS] 使用本地模型缓存: {found}")

        print("[TTS] 正在初始化神经网络（延迟加载）...")
        use_gpu = self._mode == "cuda"
        try:
            self._tts = TTS(self.model, gpu=use_gpu, progress_bar=True)
        except TypeError:
            # 新版 coqui-tts 签名变化时的回退
            self._tts = TTS(self.model, progress_bar=True)
        print("[TTS] 模型加载完成。")

    # ------------------------------------------------------------ 文本规范化
    def _normalize_currency_text(self, text: str) -> str:
        if not text:
            return text

        def repl(match: re.Match) -> str:
            symbol = match.group("sym")
            amount = match.group("amt").replace(",", "")
            if "." in amount:
                integer_part, frac_part = amount.split(".", 1)
                frac = (frac_part + "00")[:2]
            else:
                integer_part, frac = amount, ""

            symbol_map = {
                "$": "dollar",
                "€": "euro",
                "£": "pound",
                "¥": "yen",
                "￥": "yuan",
                "￡": "pound",
            }
            currency = symbol_map.get(symbol) or symbol

            try:
                int_val = int(integer_part) if integer_part != "" else 0
            except ValueError:
                int_val = 0

            if num2words is not None:
                try:
                    int_words = num2words(int_val, lang="en")
                except Exception:
                    int_words = str(int_val)
            else:
                int_words = str(int_val)

            if currency in ("yen", "yuan"):
                currency_word = currency
            else:
                currency_word = currency + ("s" if int_val != 1 else "")

            if frac:
                if currency in ("yen", "yuan"):
                    return f"{int_words} {currency_word}"
                try:
                    frac_val = int(frac)
                except ValueError:
                    frac_val = 0
                if frac_val == 0:
                    return f"{int_words} {currency_word}"
                if num2words is not None:
                    try:
                        frac_words = num2words(frac_val, lang="en")
                    except Exception:
                        frac_words = str(frac_val)
                else:
                    frac_words = str(frac_val)
                return f"{int_words} {currency_word} and {frac_words} cents"

            return f"{int_words} {currency_word}"

        pattern = re.compile(r"(?P<sym>[\$€£¥￥￡])\s*(?P<amt>[0-9][0-9,]*(?:\.[0-9]+)?)")
        return pattern.sub(repl, text)

    def _number_to_words(self, num_str: str) -> str:
        if not num_str:
            return num_str
        s = num_str.replace(",", "")
        if "." in s:
            int_part, frac_part = s.split(".", 1)
        else:
            int_part, frac_part = s, ""

        try:
            int_val = int(int_part) if int_part != "" else 0
        except ValueError:
            int_words = int_part
        else:
            if num2words is not None:
                try:
                    int_words = num2words(int_val, lang="en")
                except Exception:
                    int_words = str(int_val)
            else:
                int_words = str(int_val)

        if frac_part == "":
            return int_words

        digit_map = {
            "0": "zero", "1": "one", "2": "two", "3": "three", "4": "four",
            "5": "five", "6": "six", "7": "seven", "8": "eight", "9": "nine",
        }
        frac_words = " ".join(digit_map.get(d, d) for d in frac_part)
        return f"{int_words} point {frac_words}"

    def _normalize_numbers(self, text: str) -> str:
        if not text:
            return text
        pattern = re.compile(r"(?<!\w)(?P<num>\d{1,3}(?:,\d{3})*(?:\.\d+)?|\d+(?:\.\d+)?)(?!\w)")
        return pattern.sub(lambda m: self._number_to_words(m.group("num")), text)

    def preprocess(self, text: str) -> str:
        text = self._normalize_currency_text(text)
        text = self._normalize_numbers(text)
        if len(text.split()) <= 1:
            text = "Oh, " + text
        return text

    # ------------------------------------------------------------ 合成
    def get_file(self, text: str, path: str) -> None:
        if not text:
            return
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)

        text = self.preprocess(text)
        print(f"[TTS] 合成语音: {text[:60]}")

        self._ensure_tts()
        self._tts.tts_to_file(
            text=text,
            speaker_wav=self.target_voice_path,
            language="en",
            file_path=str(p),
        )

    def get_voice(self, text: str) -> Optional[bytes]:
        if not text:
            return None
        if text in self._cache:
            return self._cache[text]

        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmpf:
            tmp_path = tmpf.name
        try:
            self.get_file(text, tmp_path)
            with open(tmp_path, "rb") as f:
                data = f.read()
            self._cache[text] = data
            return data
        finally:
            try:
                os.remove(tmp_path)
            except Exception:
                pass
