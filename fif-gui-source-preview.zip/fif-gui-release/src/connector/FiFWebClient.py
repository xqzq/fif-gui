"""FiF 口语训练系统 Web 客户端。

相对上游 fif_gui 的改动（对应线上 2024+ 版本）：
- getLevelInfo 由 POST form 改为 GET query（保留 POST 回退）。
- stuUnitInfo 补 bankType 参数。
- 新增 getStudentTaskChallengeConfig 挑战次数预检。
- 新增 getH5Url（DEKARON_MAIN）取挑战 iframe 地址。
- 登录增加同源 localStorage 兜底。
- 挑战流程的 iframe / 按钮选择器改为容错轮询。
"""

from __future__ import annotations

import json
import logging
import re
from typing import Optional

from playwright.sync_api import Page, sync_playwright

logger = logging.getLogger(__name__)


class FiFWebClient:
    # 站点地址
    urls = {
        "login": "https://www.fifedu.com/iplat/fifLogin/index.html?v=5.4.4",
        "home": "https://www.fifedu.com/iplat/html/home/home.html",
        "ai_task": (
            "https://static.fifedu.com/static/fiforal/kyxl-web-static/"
            "student-h5/index.html#/pages/teaching/teaching"
        ),
        # 挑战页（student-h5 壳），由壳内部再请求 getH5Url 装载 assessment iframe
        "unit_test": (
            "https://static.fifedu.com/static/fiforal/kyxl-web-static/"
            "student-h5/index.html#/pages/webView/testWebView/testWebView"
            "?userId={}&taskId={}&unitId={}&gId={}"
        ),
        # assessment SPA 直链（fallback）
        "assessment": (
            "https://static.fifedu.com/static/fiforal/kyxl-web-static/"
            "assessment/#/dekaronData/dekaronMain"
        ),
    }

    # 接口地址
    api_urls = {
        "get_user_info": "https://moral.fifedu.com/kyxl-app/account/getUserInfo",
        "get_task_list": "https://moral.fifedu.com/kyxl-app/stu/task/teaTaskList",
        "get_task_detail": "https://moral.fifedu.com/kyxl-app/task/stu/teaTaskDetail",
        "get_unit_info": "https://moral.fifedu.com/kyxl-app/stu/column/stuUnitInfo?unitId={}&taskId={}",
        "get_test_info": "https://moral.fifedu.com/kyxl-app/column/getLevelInfo",
        "get_challenge_config": (
            "https://moral.fifedu.com/kyxl-app/task/stu/getStudentTaskChallengeConfig"
        ),
        "get_h5_url": "https://moral.fifedu.com/kyxl-app//h5/getH5Url",
        "post_test_results": (
            "https://moral.fifedu.com/kyxl-app-challenge/evaluation/submitChallengeResults"
        ),
    }

    def __init__(self, headless: bool = False, slow_mo: int = 0):
        self.user_auth = {"token": None, "source": None}
        self.user_info = None
        self.playwright = sync_playwright().start()
        self.browser = self.playwright.chromium.launch(
            headless=headless,
            slow_mo=slow_mo,
            args=["--use-fake-ui-for-media-stream", "--autoplay-policy=no-user-gesture-required"],
        )
        self.context = self.browser.new_context(
            permissions=["microphone"],
            viewport={"width": 1280, "height": 900},
        )
        self.page = self.context.new_page()

    # ------------------------------------------------------------------ 生命周期
    def close(self) -> None:
        try:
            if getattr(self, "browser", None):
                self.browser.close()
        except Exception as e:  # pragma: no cover
            logger.exception("关闭浏览器失败: %s", e)
        try:
            if getattr(self, "playwright", None):
                self.playwright.stop()
        except Exception as e:  # pragma: no cover
            logger.exception("停止 playwright 失败: %s", e)

    def __del__(self):  # pragma: no cover
        self.close()

    # ------------------------------------------------------------------ 鉴权头
    def _headers(self) -> dict:
        return {
            "Authorization": "Bearer " + str(self.user_auth["token"]),
            "source": str(self.user_auth["source"]),
        }

    # ------------------------------------------------------------------ 登录
    def login(self, username: str, password: str) -> dict:
        self.page.goto(self.urls["login"], timeout=60000)
        self.page.wait_for_timeout(1500)

        try:
            self._fill_login_form(username, password)
        except Exception:
            logger.warning("Automatic login form submission incomplete; finish login in the browser.")
        # Background requests may prevent networkidle even after a successful login.
        self.page.wait_for_timeout(1500)

        token, source = self._grab_token()
        self.user_auth["token"] = token
        self.user_auth["source"] = source

        if not token:
            raise Exception("登录失败：未能获取 Authorization token")

        return self.get_user_info()

    def _fill_login_form(self, username: str, password: str) -> None:
        user_selectors = [
            'input[name="user"]',
            'input[name="username"]',
            'input[placeholder*="账号"]',
            'input[placeholder*="用户"]',
            'input[type="text"]',
        ]
        pass_selectors = [
            'input[name="pass"]',
            'input[name="password"]',
            'input[placeholder*="密码"]',
            'input[type="password"]',
        ]
        self._fill_first(user_selectors, username)
        self._fill_first(pass_selectors, password)

        for name in ("登录", "登 录", "立即登录"):
            try:
                btn = self.page.get_by_role("button", name=name).first
                if btn.is_visible(timeout=2000):
                    btn.click()
                    return
            except Exception:
                continue
        # 兜底：提交按钮
        try:
            self.page.locator('button[type="submit"]').first.click(timeout=3000)
        except Exception:
            logger.warning("未找到登录按钮，尝试回车提交")
            self.page.keyboard.press("Enter")

    def _fill_first(self, selectors, value: str) -> bool:
        for sel in selectors:
            try:
                loc = self.page.locator(sel).first
                if loc.is_visible(timeout=1500):
                    loc.fill(value)
                    return True
            except Exception:
                continue
        return False

    def _grab_token(self):
        """优先走「FiF口语训练系统」弹窗；失败则读同源 localStorage。"""
        import time
        from urllib.parse import urlsplit

        logger.info("等待口语站登录，最多 180 秒；可在打开的浏览器中完成验证码并进入 FiF 口语。")
        deadline = time.monotonic() + 180
        clicked = set()
        while time.monotonic() < deadline:
            pages = [p for p in self.context.pages if not p.is_closed()]
            if not pages:
                raise RuntimeError("登录浏览器已关闭，请重新开始登录。")
            for p in pages:
                try:
                    location = urlsplit(p.url)
                    # Never inspect storage on unrelated pages or log credential values.
                    if location.hostname == "static.fifedu.com":
                        data = p.evaluate("""() => {
                            const unwrap = value => {
                                if (value === null) return null;
                                try {
                                    const parsed = JSON.parse(value);
                                    if (parsed && typeof parsed === 'object') return parsed.data ?? null;
                                    return parsed;
                                } catch (_) { return value; }
                            };
                            return {
                                token: unwrap(localStorage.getItem('Authorization')),
                                source: unwrap(localStorage.getItem('source'))
                            };
                        }""")
                        token, source = data.get("token"), data.get("source")
                        if isinstance(token, str) and token.strip() and source is not None:
                            self.page = p
                            logger.info("口语站登录凭据已就绪。")
                            return token.removeprefix("Bearer ").strip(), str(source)
                    if location.hostname == "www.fifedu.com" and id(p) not in clicked:
                        link = p.get_by_text(re.compile(r"FiF\s*口语(?:训练系统)?", re.I)).first
                        if link.count() and link.is_visible():
                            clicked.add(id(p))
                            link.click(timeout=2500)
                except Exception:
                    # Navigation can destroy the execution context; retry on the next tick.
                    continue
            pages[0].wait_for_timeout(750)
        raise RuntimeError("等待口语站登录超时（180秒）。请在弹出的浏览器完成登录/验证码，并点击进入 FiF 口语；保持无头模式关闭。")

    # ------------------------------------------------------------------ 用户信息
    def get_user_info(self) -> dict:
        if self.user_info is not None:
            return self.user_info
        response = self.page.request.fetch(
            self.api_urls["get_user_info"],
            method="GET",
            headers=self._headers(),
            timeout=30000,
        )
        # Some deployments expose this read operation only as POST.
        if response.status == 405:
            response = self.page.request.fetch(
                self.api_urls["get_user_info"], method="POST",
                headers=self._headers(), form={}, timeout=30000,
            )
        if response.status in (401, 403):
            raise RuntimeError("口语站用户信息鉴权失败，请在浏览器重新登录口语系统。")
        if response.status != 200:
            raise RuntimeError(
                f"口语站 getUserInfo 返回 HTTP {response.status}；已携带当前会话鉴权头。"
            )
        try:
            payload = response.json()
        except Exception:
            raise RuntimeError("口语站 getUserInfo 返回了非 JSON 内容。") from None
        if not isinstance(payload, dict):
            raise RuntimeError("口语站 getUserInfo 返回格式异常。")
        status = payload.get("status")
        if status not in (1, "1", "SUCCESS"):
            raise RuntimeError("口语站 getUserInfo 未返回成功状态，请检查登录是否仍有效。")
        data = payload.get("data")
        if not isinstance(data, dict) or data.get("userId") in (None, ""):
            raise RuntimeError("口语站 getUserInfo 响应缺少 data.userId；尚未开始读取任务。")
        self.user_info = payload
        return self.user_info

    def get_user_id(self) -> str:
        return self.get_user_info()["data"]["userId"]

    # ------------------------------------------------------------------ 任务 / 单元
    def get_task_list(self, page: Page, status: int = 1) -> dict:
        response = page.request.fetch(
            self.api_urls["get_task_list"], method="post",
            headers=self._headers(),
            form={"userId": self.get_user_id(), "status": status, "page": 1},
            timeout=30000,
        )
        if response.status != 200:
            raise RuntimeError(f"teaTaskList HTTP {response.status}（筛选 status={status}）")
        try:
            payload = response.json()
        except Exception:
            raise RuntimeError("teaTaskList 返回非 JSON 内容。") from None
        if not isinstance(payload, dict):
            raise RuntimeError("teaTaskList 返回值不是对象。")
        if payload.get("status") not in (1, "1", "SUCCESS"):
            raise RuntimeError("teaTaskList 未返回成功状态，请检查口语站登录是否有效。")
        data = payload.get("data")
        if not isinstance(data, dict) or not isinstance(data.get("ttiList"), list):
            # Report schema only; task contents and credentials stay private.
            keys = ', '.join(sorted(data.keys())) if isinstance(data, dict) else type(data).__name__
            raise RuntimeError(f"teaTaskList 返回结构变化：data 字段为 {keys}；预期 ttiList 数组。")
        return payload

    def get_ttd_list(self, page: Page, task_id) -> dict:
        response = page.request.fetch(
            self.api_urls["get_task_detail"],
            method="post",
            form={"userId": self.get_user_id(), "id": task_id},
            headers=self._headers(),
        )
        json_data = response.json()
        if json_data.get("status") == -1:
            raise Exception(f"获取任务详情失败: {json_data.get('msg')}")
        return json_data

    def get_unit_info(self, page: Page, unit_id, task_id, bank_type: str = "1") -> dict:
        """线上 stuUnitInfo 需要 bankType 参数。"""
        url = self.api_urls["get_unit_info"].format(unit_id, task_id)
        response = page.request.fetch(
            url,
            method="get",
            params={"bankType": bank_type},
            headers=self._headers(),
        )
        json_data = response.json()
        if json_data.get("status") == -1:
            raise Exception(f"获取单元信息失败: {json_data.get('msg')}")
        return json_data

    # ------------------------------------------------------------------ 挑战配置
    def get_challenge_config(self, page: Page, task_id, level_id, student_id: str) -> dict:
        """返回 answerCount / challengeTimes，用于判断次数是否用尽。"""
        response = page.request.fetch(
            self.api_urls["get_challenge_config"],
            method="post",
            form={"taskId": task_id, "levelId": level_id, "studentId": student_id},
            headers=self._headers(),
        )
        try:
            return response.json()
        except Exception:
            logger.warning("挑战配置解析失败，跳过次数校验")
            return {"data": {}}

    def get_h5_url(self, page: Page, page_type: str, **kw) -> dict:
        params = {"pageType": page_type, **kw}
        response = page.request.fetch(
            self.api_urls["get_h5_url"],
            method="get",
            params=params,
            headers=self._headers(),
        )
        try:
            return response.json()
        except Exception:
            return {"data": None}

    # ------------------------------------------------------------------ 取答案
    def get_level_answer(self, page: Page, level_id, level_name: Optional[str] = None):
        """取某关卡的答案文本列表。

        线上已改为 GET + query；这里 GET 优先，失败回退 POST form。
        """
        response = None
        # GET 优先
        try:
            data = page.request.fetch(
                self.api_urls["get_test_info"],
                method="get",
                params={"levelId": level_id},
                headers=self._headers(),
            ).json()
            if data.get("status") == 1:
                response = data
        except Exception as e:
            logger.warning("GET getLevelInfo 失败，回退 POST: %s", e)

        # POST 回退
        if response is None:
            response = page.request.fetch(
                self.api_urls["get_test_info"],
                method="post",
                form={"levelId": level_id},
                headers=self._headers(),
            ).json()

        if response.get("status") != 1:
            raise Exception(f"获取答案失败: {response.get('msg')}")

        challenge_modes = [
            i for i in response["data"]["content"]["moshi"] if i["name"] == "挑战"
        ]
        if not challenge_modes:
            # 兜底：没有「挑战」模式时取第一个模式
            modes = response["data"]["content"]["moshi"]
            if not modes:
                raise Exception("未找到挑战模式内容")
            challenge_modes = [modes[0]]

        qcontent = challenge_modes[0]["question"]["qcontent"]

        # 对话模式：有 roles
        if "roles" in qcontent:
            return self._parse_dialogue(qcontent)

        # 非对话模式：跟读
        return self._parse_read(qcontent)

    @staticmethod
    def _parse_dialogue(qcontent: dict):
        text = qcontent.get("text", "")
        if not text:
            return []
        sentences = [seg.strip() for seg in text.split("##") if seg.strip()]
        roles = qcontent.get("roles", "")

        if not roles:
            return [re.sub(r"^\w+:\s*", "", s) for s in sentences if ": " in s]

        role_sentences: dict = {}
        for sent in sentences:
            if ": " in sent:
                role, content = sent.split(": ", 1)
                role_sentences.setdefault(role, []).append(content.strip())

        result = []
        for r in roles.split("#"):
            if r in role_sentences:
                result.extend(role_sentences[r])
        if not result:
            for v in role_sentences.values():
                result.extend(v)
        return result

    @staticmethod
    def _parse_read(qcontent: dict):
        answer = []
        for item in qcontent.get("item", []):
            for q in item.get("questions", []):
                title = q.get("title", "") or ""
                title = re.sub(r"<[^>]+>", "", title).strip()
                if title:
                    answer.append(title)
        return answer

    # ------------------------------------------------------------------ 挑战流程
    def start_level_test(
        self,
        page: Page,
        speaker,
        unit_id,
        task_id,
        level_id,
        level_name: Optional[str] = None,
        bank_type: str = "1",
    ) -> None:
        print(f"[client] 尝试加载 {level_id} 答案。")
        answer = self.get_level_answer(page, level_id, level_name)
        if not answer:
            raise Exception("答案为空，无法作答")
        print(f"[client] 已加载 {len(answer)} 条答案。")

        user_id = self.get_user_id()
        page.goto(self.urls["unit_test"].format(user_id, task_id, unit_id, level_id))
        page.wait_for_load_state("load")

        frame = self._wait_challenge_frame(page)
        self._click_tab(frame, "挑战")
        self._click_button(frame, "开始挑战")
        page.wait_for_timeout(3000)

        for idx, text in enumerate(answer):
            print(f"[client] 等待开始录音（第 {idx + 1} 条）。")
            self._wait_text_visible(frame, "结束录音", timeout=45000)
            print(f"[client] 正在回答第 {idx + 1} 条：{text}")
            speaker.speak(text)
            print(f"[client] 第 {idx + 1} 条播放完成，点击结束录音。")
            self._click_text(frame, "结束录音")
            page.wait_for_timeout(1500)

        print("[client] 挑战完成，等待 AI 评分提交。")
        self._wait_submit(page, frame)
        print("[client] 当前单元结束。")

    # -------------------------------------------------- 挑战 UI 容错助手
    def _wait_challenge_frame(self, page: Page, timeout: int = 60000):
        """等到 iframe 出现并返回可在其中定位元素的 frame locator。"""
        deadline = timeout
        step = 500
        waited = 0
        while waited < deadline:
            try:
                if page.locator("iframe").count() > 0:
                    return page.frame_locator("iframe")
            except Exception:
                pass
            page.wait_for_timeout(step)
            waited += step
        raise Exception("挑战页面 iframe 未加载")

    def _click_tab(self, frame, name: str) -> None:
        for getter in (
            lambda: frame.get_by_role("tab", name=name),
            lambda: frame.get_by_text(name, exact=True),
        ):
            try:
                loc = getter().first
                loc.wait_for(state="visible", timeout=15000)
                loc.click()
                return
            except Exception:
                continue
        raise Exception(f"未找到标签：{name}")

    def _click_button(self, frame, name: str) -> None:
        for getter in (
            lambda: frame.get_by_role("button", name=name),
            lambda: frame.get_by_text(name, exact=True),
        ):
            try:
                loc = getter().first
                loc.wait_for(state="visible", timeout=15000)
                loc.click()
                return
            except Exception:
                continue
        raise Exception(f"未找到按钮：{name}")

    def _click_text(self, frame, text: str) -> None:
        loc = frame.get_by_text(text).first
        loc.wait_for(state="visible", timeout=15000)
        loc.click()

    def _wait_text_visible(self, frame, text: str, timeout: int = 45000) -> None:
        loc = frame.get_by_text(text).first
        loc.wait_for(state="visible", timeout=timeout)

    def _wait_submit(self, page: Page, frame, timeout: int = 60000) -> None:
        for name in ("AI 评分", "AI评分", "评分"):
            try:
                frame.get_by_text(name).first.wait_for(state="visible", timeout=timeout // 3)
                return
            except Exception:
                continue
        logger.warning("未检测到评分提示，等待固定时间后继续")
        page.wait_for_timeout(5000)

    # ------------------------------------------------------------------ 访问器
    def get_page(self) -> Page:
        return self.page

    def get_context(self):
        return self.context

    def get_browser(self):
        return self.browser

    def get_playwright(self):
        return self.playwright

    def get_urls(self) -> dict:
        return self.urls
