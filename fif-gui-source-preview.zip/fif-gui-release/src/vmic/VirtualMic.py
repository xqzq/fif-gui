"""虚拟麦克风 / 音频播放封装。

- Linux：pulseaudio module-pipe-source，ffmpeg -re 实时写入。
- Windows：pyaudio 输出到指定设备（默认匹配 VB-Cable 的 "CABLE Input"）。
"""

from __future__ import annotations

import os
import platform
import wave
from pathlib import Path

CHUNK = 1024

try:
    import pyaudio
except Exception:  # pragma: no cover
    pyaudio = None


class VirtualMic:
    def __init__(
        self,
        device_name: str = "VirtualPipeMic",
        fmt: str = "s16le",
        rate: str = "44100",
        channels: str = "2",
        output_device: str = "CABLE Input",
    ):
        self.device_name = device_name
        self.format = fmt
        self.rate = int(rate)
        self.channels = int(channels)
        self.output_device = output_device
        self.system = platform.system()

        if self.system == "Linux":
            self._init_linux()
        elif self.system == "Windows":
            self._init_windows()
        else:
            raise Exception(f"不支持的操作系统: {self.system}")

    # ------------------------------------------------------------ Linux
    def _init_linux(self) -> None:
        retry = 0
        while not Path(f"/tmp/{self.device_name}").exists():
            retry += 1
            if retry > 5:
                raise Exception(
                    "[VirtualMic] 虚拟声卡初始化失败，请确认 pulseaudio/pactl 可用。"
                )
            print("[VirtualMic] 正在初始化虚拟声卡。")
            os.system(
                "pactl load-module module-pipe-source source_name={} "
                "file=/tmp/{} format={} rate={} channels={}".format(
                    self.device_name, self.device_name, self.format, self.rate, self.channels
                )
            )
            os.system(
                "pacmd update-source-proplist {} device.description={}".format(
                    self.device_name, self.device_name
                )
            )
            os.system("pacmd set-default-source {}".format(self.device_name))
        print("[VirtualMic] 虚拟声卡初始化完成。")

    # ------------------------------------------------------------ Windows
    def _init_windows(self) -> None:
        print("[VirtualMic] Windows 系统，使用 pyaudio 输出音频。")
        if pyaudio is None:
            print("[VirtualMic] 警告：pyaudio 未安装，无法播放音频。")
            return
        idx, name = self._find_output_device()
        if idx is None:
            print(
                f"[VirtualMic] 警告：未找到输出设备 '{self.output_device}'，"
                "将使用系统默认输出。请安装 VB-Cable 或修改「虚拟麦克风设备」。"
            )
        else:
            print(f"[VirtualMic] 使用输出设备 [{idx}] {name}")

    def _find_output_device(self):
        if pyaudio is None:
            return None, None
        p = pyaudio.PyAudio()
        try:
            target = (self.output_device or "").lower()
            fallback = None
            for i in range(p.get_device_count()):
                info = p.get_device_info_by_index(i)
                if int(info.get("maxOutputChannels", 0)) <= 0:
                    continue
                name = str(info.get("name", ""))
                if target and target in name.lower():
                    return i, name
                if fallback is None:
                    fallback = (i, name)
            return fallback
        finally:
            p.terminate()

    # ------------------------------------------------------------ 播放
    def play(self, file_path: str) -> None:
        if not Path(file_path).exists():
            print(f"[VirtualMic] 音频文件不存在: {file_path}")
            return
        if self.system == "Linux":
            self._play_linux(file_path)
        elif self.system == "Windows":
            self._play_windows(file_path)

    def _play_linux(self, file_path: str) -> None:
        print(f"[VirtualMic] 音频流写入虚拟声卡: {file_path}")
        os.system(
            "ffmpeg -re -i {} -f {} -ar {} -ac {} -async 1 "
            "-filter:a volume=0.8 - > /tmp/{} 2>/dev/null".format(
                file_path, self.format, self.rate, self.channels, self.device_name
            )
        )
        print(f"[VirtualMic] 音频流结束: {file_path}")

    def _play_windows(self, file_path: str) -> None:
        print(f"[VirtualMic] Windows 播放: {file_path}")
        if pyaudio is None:
            print("[VirtualMic] 错误：pyaudio 未安装，无法播放。")
            return

        p = None
        stream = None
        try:
            dev_idx, _ = self._find_output_device()
            with wave.open(file_path, "rb") as wf:
                p = pyaudio.PyAudio()
                stream = p.open(
                    format=p.get_format_from_width(wf.getsampwidth()),
                    channels=wf.getnchannels(),
                    rate=wf.getframerate(),
                    output=True,
                    output_device_index=dev_idx,
                )
                data = wf.readframes(CHUNK)
                while data:
                    stream.write(data)
                    data = wf.readframes(CHUNK)
        except Exception as e:
            print(f"[VirtualMic] 播放错误: {e}")
        finally:
            try:
                if stream is not None:
                    stream.stop_stream()
                    stream.close()
            except Exception:
                pass
            try:
                if p is not None:
                    p.terminate()
            except Exception:
                pass
        print("[VirtualMic] Windows 播放完成。")
