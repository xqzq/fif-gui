"""TTS 合成 + 虚拟麦克风播放的薄封装。"""

from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Optional

from tts.TTSSolver import TTSSolver
from vmic.VirtualMic import VirtualMic


class Speaker:
    def __init__(
        self,
        tts_model_name: str,
        mode: str,
        vmic: str,
        target_voice_path: str,
        output_device: str = "CABLE Input",
    ):
        self.tts_solver = TTSSolver(tts_model_name, mode, target_voice_path)
        self.virtual_mic = VirtualMic(vmic, "s16le", "44100", "2", output_device)
        Path("tmp").mkdir(parents=True, exist_ok=True)

    def speak(self, text: str) -> None:
        if not text:
            return
        with tempfile.NamedTemporaryFile(suffix=".wav", dir="tmp", delete=False) as tf:
            temp_path = tf.name
        try:
            self.tts_solver.get_file(text, temp_path)
            self.virtual_mic.play(temp_path)
        finally:
            try:
                Path(temp_path).unlink()
            except Exception:
                pass  # 可能正被播放
