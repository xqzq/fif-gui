# -*- coding: utf-8 -*-
"""无 GUI 命令行入口。

用法：
    python src/cli.py --stats                 # 查看断点统计
    python src/cli.py --dry-run               # 登录 + 取答案，不播放不提交
    python src/cli.py --run                   # 完整作答（带断点续跑）
    python src/cli.py --level-id LEVEL        # 只测某关卡取答案
    python src/cli.py --reset-failed          # 清除失败记录
    python src/cli.py --reset-all             # 清除全部进度

断点文件：state/checkpoint.json
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import traceback

SRC_DIR = os.path.dirname(os.path.abspath(__file__))
if SRC_DIR not in sys.path:
    sys.path.insert(0, SRC_DIR)

from checkpoint import Checkpoint  # noqa: E402

os.makedirs("tmp", exist_ok=True)
os.makedirs("draft", exist_ok=True)
os.makedirs("state", exist_ok=True)
os.makedirs("logs", exist_ok=True)


def _load_client():
    """惰性导入，使 --stats / --reset-* 不依赖 playwright。"""
    from connector.FiFWebClient import FiFWebClient
    return FiFWebClient


def _load_speaker():
    from speaker.Speaker import Speaker
    return Speaker


def load_config(path="config.json") -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser()
    p.add_argument("--config", default="config.json")
    p.add_argument("--dry-run", action="store_true", help="只取答案，不播放")
    p.add_argument("--run", action="store_true", help="完整作答")
    p.add_argument("--headless", action="store_true")
    p.add_argument("--level-id", default=None, help="只测该关卡取答案")
    p.add_argument("--no-resume", action="store_true", help="忽略断点全部重跑")
    p.add_argument("--stats", action="store_true")
    p.add_argument("--reset-failed", action="store_true")
    p.add_argument("--reset-all", action="store_true")
    return p


def cmd_run(cfg: dict, ckpt: Checkpoint, args) -> None:
    """完整作答流程。"""
    Speaker = _load_speaker()
    FiFWebClient = _load_client()
    speaker = Speaker(
        cfg.get("tts_model", "tts_models/multilingual/multi-dataset/your_tts"),
        cfg.get("tts_mode", "cpu"),
        cfg.get("vmic_name", "VirtualPipeMic"),
        cfg.get("target_voice_path", "draft/target_voice.wav"),
        cfg.get("output_device", "CABLE Input"),
    )
    fif = FiFWebClient(headless=args.headless)
    skip_done = not args.no_resume
    max_retries = int(cfg.get("max_retries", 2))
    bank_type = str(cfg.get("bank_type", "1"))
    skip_score = int(cfg.get("skip_score", 80))
    dry = args.dry_run

    try:
        info = fif.login(cfg["username"], cfg["password"])
        print("登录成功:", info.get("data", {}).get("realName"))
        user_id = fif.get_user_id()

        tasks = fif.get_task_list(fif.get_page()).get("data", {}).get("ttiList", [])
        for t in tasks:
            task_id = t["id"]
            print(f"任务: {t.get('taskName')} id={task_id}")
            ttds = fif.get_ttd_list(fif.get_page(), task_id).get("data", {}).get("ttdList", [])
            for ttd in ttds:
                unit_name = ttd.get("unitName", "")
                unit = fif.get_unit_info(
                    fif.get_page(), ttd["unitid"], t["taskId"], bank_type
                ).get("data", {})
                unit_id = unit.get("id", ttd.get("unitid"))
                print(f"  单元: {unit_name} id={unit_id}")

                for lv in unit.get("levelList", []):
                    level_id = lv.get("levelId")
                    level_name = lv.get("levelName", "")

                    if skip_done and ckpt.is_done(task_id, unit_id, level_id):
                        print(f"    {level_name}: 已完成，跳过")
                        continue

                    if ckpt.failure_count(task_id, unit_id, level_id) > max_retries:
                        print(f"    {level_name}: 失败次数超上限，跳过")
                        continue

                    if lv.get("levelScore", 0) >= skip_score:
                        print(f"    {level_name}: 已达标，跳过")
                        continue

                    print(f"    {level_name}: 处理中...")
                    try:
                        if dry:
                            ans = fif.get_level_answer(fif.get_page(), level_id, level_name)
                            print(f"      -> 答案 {len(ans)} 条")
                            continue

                        fif.start_level_test(
                            fif.get_page(), speaker,
                            unit_id=unit_id, task_id=task_id,
                            level_id=level_id, level_name=level_name,
                            bank_type=bank_type,
                        )
                        ckpt.mark_done(task_id, unit_id, level_id, level_name=level_name)
                        print("      -> 完成")
                    except Exception as e:
                        fails = ckpt.mark_failed(
                            task_id, unit_id, level_id, error=str(e), level_name=level_name
                        )
                        print(f"      -> 失败（第 {fails} 次）: {e}")
    finally:
        fif.close()


def cmd_inspect(cfg: dict, ckpt: Checkpoint, args) -> None:
    """登录并打印层级结构；--dry-run 顺带取答案。"""
    FiFWebClient = _load_client()
    fif = FiFWebClient(headless=args.headless)
    bank_type = str(cfg.get("bank_type", "1"))
    try:
        info = fif.login(cfg["username"], cfg["password"])
        print("登录成功:", info.get("data", {}).get("realName"))
        user_id = fif.get_user_id()

        if args.level_id:
            answers = fif.get_level_answer(fif.get_page(), args.level_id)
            print(f"答案 {len(answers)} 条:")
            for i, a in enumerate(answers, 1):
                print(f"  {i}. {a}")
            return

        tasks = fif.get_task_list(fif.get_page()).get("data", {}).get("ttiList", [])
        for t in tasks:
            print(f"任务: {t.get('taskName')} id={t.get('id')}")
            ttds = fif.get_ttd_list(fif.get_page(), t["id"]).get("data", {}).get("ttdList", [])
            for ttd in ttds:
                print(f"  单元: {ttd.get('unitName')} id={ttd.get('id')}")
                unit = fif.get_unit_info(
                    fif.get_page(), ttd["unitid"], t["taskId"], bank_type
                ).get("data", {})
                unit_id = unit.get("id", ttd.get("unitid"))
                for lv in unit.get("levelList", []):
                    level_id = lv.get("levelId")
                    tag = " [已完成]" if ckpt.is_done(t["id"], unit_id, level_id) else ""
                    print(
                        f"    关卡: {lv.get('levelName')} id={level_id} "
                        f"分数={lv.get('levelScore')}{tag}"
                    )
                    if args.dry_run:
                        try:
                            ans = fif.get_level_answer(
                                fif.get_page(), level_id, lv.get("levelName")
                            )
                            print(f"      -> 答案 {len(ans)} 条")
                        except Exception as e:
                            print(f"      -> 取答案失败: {e}")
    finally:
        fif.close()


def main() -> None:
    args = build_parser().parse_args()
    ckpt = Checkpoint()
    do_run = args.run or args.dry_run or args.level_id

    if args.stats or not (do_run or args.reset_failed or args.reset_all):
        s = ckpt.stats()
        print(f"[progress] 总计 {s['total']}，已完成 {s['done']}，"
              f"失败 {s['failed']}，待处理 {s['pending']}")
        for line in ckpt.summary_lines():
            print(line)
        if args.stats:
            return

    if args.reset_failed:
        print(f"[progress] 已清除 {ckpt.reset(only_failed=True)} 条失败记录。")
        return

    if args.reset_all:
        print(f"[progress] 已清除 {ckpt.reset()} 条进度记录。")
        return

    if not os.path.exists(args.config):
        print(f"未找到配置 {args.config}，请先 copy config.example.json config.json")
        return

    cfg = load_config(args.config)

    if not os.path.exists(cfg.get("target_voice_path", "")) and args.run and not args.dry_run:
        print(f"音色文件不存在: {cfg.get('target_voice_path')}")
        print("可用以下命令生成：")
        print("  python src/voice_tool.py builtin draft/target_voice.wav")
        print("  python src/voice_tool.py record  draft/target_voice.wav --seconds 15")
        return

    try:
        if args.run:
            cmd_run(cfg, ckpt, args)
        else:
            cmd_inspect(cfg, ckpt, args)
    except Exception:
        print("[cli] 异常:")
        traceback.print_exc()


if __name__ == "__main__":
    main()
