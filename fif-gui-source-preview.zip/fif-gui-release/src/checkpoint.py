"""断点续跑 / 进度记录。

记录每个关卡的处理状态，支持：
- 已完成关卡跳过（重启后续跑）
- 失败关卡独立计数与重试上限
- 结果落盘 state/checkpoint.json，进程崩溃不丢进度
- 查询统计与按范围重置
"""

from __future__ import annotations

import json
import os
import threading
import time
from typing import Optional

STATE_DIR = "state"
DEFAULT_PATH = os.path.join(STATE_DIR, "checkpoint.json")

STATUS_DONE = "done"
STATUS_FAILED = "failed"


class Checkpoint:
    def __init__(self, path: str = DEFAULT_PATH):
        self.path = path
        self._lock = threading.Lock()
        self.data = {
            "version": 1,
            "created": time.time(),
            "updated": None,
            "levels": {},  # key -> record
        }
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        self.load()

    # ------------------------------------------------------------ 键
    @staticmethod
    def make_key(task_id, unit_id, level_id) -> str:
        return f"{task_id}:{unit_id}:{level_id}"

    # ------------------------------------------------------------ 持久化
    def load(self) -> None:
        if not os.path.exists(self.path):
            return
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                loaded = json.load(f)
            if isinstance(loaded, dict) and "levels" in loaded:
                self.data.update(loaded)
        except Exception as e:  # pragma: no cover
            print(f"[checkpoint] 读取失败，忽略旧进度: {e}")

    def save(self) -> None:
        with self._lock:
            self.data["updated"] = time.time()
            tmp = self.path + ".tmp"
            try:
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(self.data, f, ensure_ascii=False, indent=2)
                os.replace(tmp, self.path)
            except Exception as e:  # pragma: no cover
                print(f"[checkpoint] 写入失败: {e}")

    # ------------------------------------------------------------ 记录
    def get(self, task_id, unit_id, level_id) -> Optional[dict]:
        return self.data["levels"].get(self.make_key(task_id, unit_id, level_id))

    def is_done(self, task_id, unit_id, level_id) -> bool:
        rec = self.get(task_id, unit_id, level_id)
        return bool(rec and rec.get("status") == STATUS_DONE)

    def failure_count(self, task_id, unit_id, level_id) -> int:
        rec = self.get(task_id, unit_id, level_id)
        return int(rec.get("failures", 0)) if rec else 0

    def mark_done(self, task_id, unit_id, level_id, **extra) -> None:
        key = self.make_key(task_id, unit_id, level_id)
        rec = self.data["levels"].get(key, {})
        rec.update({
            "status": STATUS_DONE,
            "task_id": str(task_id),
            "unit_id": str(unit_id),
            "level_id": str(level_id),
            "finished_at": time.time(),
            "failures": rec.get("failures", 0),
        })
        rec.update(extra)
        self.data["levels"][key] = rec
        self.save()

    def mark_failed(self, task_id, unit_id, level_id, error: str = "", **extra) -> int:
        key = self.make_key(task_id, unit_id, level_id)
        rec = self.data["levels"].get(key, {})
        rec["failures"] = int(rec.get("failures", 0)) + 1
        rec.update({
            "status": STATUS_FAILED,
            "task_id": str(task_id),
            "unit_id": str(unit_id),
            "level_id": str(level_id),
            "last_error": str(error)[:500],
            "last_failed_at": time.time(),
        })
        rec.update(extra)
        self.data["levels"][key] = rec
        self.save()
        return rec["failures"]

    # ------------------------------------------------------------ 决策
    def should_process(
        self,
        task_id,
        unit_id,
        level_id,
        skip_done: bool = True,
        max_retries: int = 2,
    ) -> tuple:
        """返回 (是否处理, 原因)。"""
        if skip_done and self.is_done(task_id, unit_id, level_id):
            return False, "已完成（断点跳过）"
        fails = self.failure_count(task_id, unit_id, level_id)
        if max_retries >= 0 and fails > max_retries:
            return False, f"失败次数 {fails} 超过上限 {max_retries}"
        return True, ""

    # ------------------------------------------------------------ 统计 / 重置
    def stats(self) -> dict:
        levels = self.data.get("levels", {})
        done = sum(1 for r in levels.values() if r.get("status") == STATUS_DONE)
        failed = sum(1 for r in levels.values() if r.get("status") == STATUS_FAILED)
        return {
            "total": len(levels),
            "done": done,
            "failed": failed,
            "pending": sum(
                1 for r in levels.values()
                if r.get("status") not in (STATUS_DONE, STATUS_FAILED)
            ),
            "updated": self.data.get("updated"),
        }

    def summary_lines(self, limit: int = 50) -> list:
        levels = self.data.get("levels", {})
        lines = []
        for key, r in list(levels.items())[:limit]:
            mark = "✓" if r.get("status") == STATUS_DONE else "✗"
            lines.append(
                f"  {mark} task={r.get('task_id')} unit={r.get('unit_id')} "
                f"level={r.get('level_id')} failures={r.get('failures', 0)}"
                + (f" err={r.get('last_error','')[:60]}" if r.get("status") == STATUS_FAILED else "")
            )
        if len(levels) > limit:
            lines.append(f"  ... 其余 {len(levels) - limit} 条省略")
        return lines

    def reset(self, task_id=None, unit_id=None, only_failed: bool = False) -> int:
        """按范围清除记录，返回清除条数。"""
        levels = self.data.get("levels", {})
        removed = 0
        for key in list(levels.keys()):
            rec = levels[key]
            if task_id is not None and str(rec.get("task_id")) != str(task_id):
                continue
            if unit_id is not None and str(rec.get("unit_id")) != str(unit_id):
                continue
            if only_failed and rec.get("status") != STATUS_FAILED:
                continue
            levels.pop(key, None)
            removed += 1
        if removed:
            self.save()
        return removed
