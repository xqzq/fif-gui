# 发布指南

本目录是独立的源码发布副本，原运行目录保留。尚未上传到 GitHub，也未创建远程仓库。

## 1. 检查待发布文件

在本目录打开 PowerShell：

```powershell
git status --short
git diff --cached --stat
python -m unittest discover -s tests -v
```

确认没有 `config.json`、日志、音色、模型、token、`.venv` 或系统驱动。`.gitignore` 只阻止新文件进入索引，已经提交的敏感文件需要单独处理。

## 2. 创建本地提交

本目录已初始化 Git 的 `main` 分支，但未代替你设置身份或创建提交。

```powershell
git add .
git diff --cached --stat
git commit -m "Prepare experimental source release"
```

若 Git 提示缺少身份，在此仓库配置你自己的名称和邮箱（推荐 GitHub 提供的 noreply 地址），再提交。

## 3. 创建 GitHub 仓库并推送

在 GitHub 新建空仓库，例如 `fif-gui`。不要勾选自动生成 README / LICENSE / .gitignore。

```powershell
git remote add origin https://github.com/YOUR_ACCOUNT/fif-gui.git
git push -u origin main
```

如果你希望显示上游 fork 关系，应先在 GitHub fork 上游，然后在其克隆中审阅和迁移本发布副本，而不是直接强制推送覆盖已有历史。

## 4. 发布版本

建议先标记为 `v0.1.0-preview.1` 并在 GitHub Releases 勾选 Pre-release。描述中写明线上任务/评分链路待验证。

仅发布源码；不要附带账号、音色、模型、浏览器、Python 安装器或 VB-CABLE 驱动。

## 后续维护

原运行项目与本发布副本不会自动同步。修改后应重新审阅差异、测试和脱敏，再提交。
