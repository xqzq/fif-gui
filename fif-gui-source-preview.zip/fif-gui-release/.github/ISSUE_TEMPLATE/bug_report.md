---
name: Bug report
about: Report a reproducible problem (redact personal data)
title: '[Bug] '
labels: bug
---

## Environment
- OS:
- Python version:
- Commit/version:
- GUI or CLI:

## Reproduction
1.

## Expected / actual behavior

## Redacted error text
Include the error type and message, not your configuration file.
Never attach passwords, tokens, student names/IDs, recordings or full API response bodies.

## Verification
- [ ] I removed personal data.
- [ ] I checked whether the teacher has published any tasks.
