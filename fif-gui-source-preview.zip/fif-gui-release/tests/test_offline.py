"""Offline regression tests: no credentials, network, model or driver needed."""
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from checkpoint import Checkpoint
import voice_tool


def load_client():
    package = types.ModuleType('playwright')
    api = types.ModuleType('playwright.sync_api')
    api.Page = object
    api.sync_playwright = Mock(side_effect=AssertionError('Browser launch disallowed in offline tests'))
    spec = importlib.util.spec_from_file_location('offline_client', ROOT / 'src/connector/FiFWebClient.py')
    module = importlib.util.module_from_spec(spec)
    with patch.dict(sys.modules, {'playwright': package, 'playwright.sync_api': api}):
        spec.loader.exec_module(module)
    return module.FiFWebClient


Client = load_client()


class CheckpointTests(unittest.TestCase):
    def test_persist_and_skip(self):
        with tempfile.TemporaryDirectory() as folder:
            path = str(Path(folder) / 'checkpoint.json')
            c = Checkpoint(path)
            c.mark_done('T', 'U', 'L')
            loaded = Checkpoint(path)
            self.assertTrue(loaded.is_done('T', 'U', 'L'))
            self.assertFalse(loaded.should_process('T', 'U', 'L')[0])

    def test_retry_limit_and_reset(self):
        with tempfile.TemporaryDirectory() as folder:
            c = Checkpoint(str(Path(folder) / 'checkpoint.json'))
            for _ in range(3):
                c.mark_failed('T', 'U', 'L', 'fixture error')
            self.assertFalse(c.should_process('T', 'U', 'L', max_retries=2)[0])
            self.assertEqual(c.reset(only_failed=True), 1)
            self.assertTrue(c.should_process('T', 'U', 'L')[0])


class ResponseTests(unittest.TestCase):
    def make_client(self, status, body):
        c = object.__new__(Client)
        c.user_info = None
        c.user_auth = {'token': 'fixture', 'source': 'fixture'}
        c.page = types.SimpleNamespace(request=Mock())
        c.page.request.fetch.return_value = types.SimpleNamespace(status=status, json=lambda: body)
        return c

    def test_profile_auth_headers(self):
        c = self.make_client(200, {'status': 1, 'data': {'userId': 'fixture-id'}})
        self.assertEqual(c.get_user_id(), 'fixture-id')
        self.assertEqual(c.page.request.fetch.call_args.kwargs['headers']['Authorization'], 'Bearer fixture')

    def test_profile_http_error(self):
        c = self.make_client(500, {})
        with self.assertRaises(RuntimeError):
            c.get_user_info()

    def test_missing_user_id(self):
        c = self.make_client(200, {'status': 1, 'data': {}})
        with self.assertRaises(RuntimeError):
            c.get_user_info()

    def test_empty_tasks_are_valid(self):
        c = self.make_client(200, {'status': 1, 'data': {'ttiList': []}})
        c.user_info = {'data': {'userId': 'fixture-id'}}
        self.assertEqual(c.get_task_list(c.page, status=0)['data']['ttiList'], [])
        self.assertEqual(c.page.request.fetch.call_args.kwargs['form']['status'], 0)

    def test_task_schema_mismatch(self):
        c = self.make_client(200, {'status': 1, 'data': {'unexpected': []}})
        c.user_info = {'data': {'userId': 'fixture-id'}}
        with self.assertRaises(RuntimeError):
            c.get_task_list(c.page)

    def test_read_parser(self):
        content = {'item': [{'questions': [{'title': '<b>Hello</b>'}, {'title': ''}]}]}
        self.assertEqual(Client._parse_read(content), ['Hello'])

    def test_dialogue_parser(self):
        content = {'roles': 'a#b', 'text': 'a: Hello##b: Hi'}
        self.assertEqual(Client._parse_dialogue(content), ['Hello', 'Hi'])


class ReleaseTests(unittest.TestCase):
    def test_private_defaults(self):
        config = json.loads((ROOT / 'config.example.json').read_text(encoding='utf-8'))
        self.assertEqual(config['username'], '')
        self.assertEqual(config['password'], '')
        self.assertTrue(config['dry_run'])
        self.assertEqual(config['skip_rules'], [])

    def test_silence_analysis(self):
        result = voice_tool.analyze_samples(bytes(3200), 2)
        self.assertEqual(result['peak'], 0)
        self.assertEqual(result['silence_ratio'], 1.0)


if __name__ == '__main__':
    unittest.main()
